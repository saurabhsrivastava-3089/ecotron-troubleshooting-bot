from functools import lru_cache
from pathlib import Path
import os

from dotenv import load_dotenv


load_dotenv()


class Settings:
    app_name: str = os.getenv("APP_NAME", "Ecotron Field Troubleshooting Bot")
    environment: str = os.getenv("ENVIRONMENT", "local")

    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    gemini_model: str = os.getenv("GEMINI_MODEL", "gemini-2.0-flash-exp")
    gemini_embedding_model: str = os.getenv("GEMINI_EMBEDDING_MODEL", "text-embedding-004")

    qdrant_url: str = os.getenv("QDRANT_URL", "")
    qdrant_api_key: str = os.getenv("QDRANT_API_KEY", "")
    qdrant_collection: str = os.getenv("QDRANT_COLLECTION", "ecotron_field_kb")
    vector_size: int = int(os.getenv("VECTOR_SIZE", "768"))

    default_docx_path: Path = Path(
        os.getenv(
            "DEFAULT_DOCX_PATH",
            r"C:\Users\Admin\Downloads\Ecotron_Field_KB_v1.2.docx",
        )
    )
    local_index_path: Path = Path("data/processed/local_chunks.json")

    @property
    def has_gemini(self) -> bool:
        return bool(self.gemini_api_key)

    @property
    def has_qdrant(self) -> bool:
        return bool(self.qdrant_url)


@lru_cache
def get_settings() -> Settings:
    return Settings()

