import hashlib
import math

from google import genai

from app.config import Settings


class EmbeddingClient:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = genai.Client(api_key=settings.gemini_api_key) if settings.has_gemini else None

    def embed_query(self, text: str) -> list[float]:
        return self.embed_documents([text])[0]

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        if self.client:
            vectors: list[list[float]] = []
            for text in texts:
                result = self.client.models.embed_content(
                    model=self.settings.gemini_embedding_model,
                    contents=text,
                )
                vectors.append(result.embeddings[0].values)
            return vectors

        return [_hash_embedding(text, self.settings.vector_size) for text in texts]


def _hash_embedding(text: str, size: int) -> list[float]:
    vector = [0.0] * size
    for token in text.lower().split():
        digest = hashlib.md5(token.encode("utf-8")).hexdigest()
        index = int(digest[:8], 16) % size
        vector[index] += 1.0
    norm = math.sqrt(sum(value * value for value in vector)) or 1.0
    return [value / norm for value in vector]

