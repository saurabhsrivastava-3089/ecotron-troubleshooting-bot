const messages = document.querySelector("#messages");
const form = document.querySelector("#chatForm");
const input = document.querySelector("#message");
const language = document.querySelector("#language");
const statusBox = document.querySelector("#status");
const indexBtn = document.querySelector("#indexBtn");

function addMessage(role, text, sources = []) {
  const card = document.createElement("div");
  card.className = `message ${role}`;
  const label = role === "user" ? "Technician" : "Assistant";
  const sourceText = sources.length
    ? `<div class="sources">Sources: ${sources.map((s) => s.title).join(", ")}</div>`
    : "";
  card.innerHTML = `<strong>${label}</strong><p>${escapeHtml(text)}</p>${sourceText}`;
  messages.appendChild(card);
  messages.scrollTop = messages.scrollHeight;
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, (char) => {
    return {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;",
    }[char];
  });
}

async function refreshHealth() {
  const response = await fetch("/api/health");
  const data = await response.json();
  statusBox.textContent = `Gemini: ${data.gemini_configured ? "configured" : "not configured"} | Qdrant: ${
    data.qdrant_configured ? "configured" : "not configured"
  } | Local index: ${data.local_index_exists ? "ready" : "missing"}`;
}

indexBtn.addEventListener("click", async () => {
  statusBox.textContent = "Indexing knowledge base...";
  try {
    const response = await fetch("/api/index", { method: "POST" });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Index failed");
    statusBox.textContent = `Indexed ${data.indexed_chunks} chunks into ${data.vector_store}.`;
  } catch (error) {
    statusBox.textContent = error.message;
  }
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = input.value.trim();
  if (!message) return;
  addMessage("user", message);
  input.value = "";

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, language: language.value }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Chat failed");
    addMessage("assistant", `${data.answer}\n\nMode: ${data.mode}`, data.sources);
  } catch (error) {
    addMessage("assistant", error.message);
  }
});

refreshHealth();
