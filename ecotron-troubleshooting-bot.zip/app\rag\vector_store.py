from qdrant_client import QdrantClient
from qdrant_client.http import models

from app.config import Settings
from app.ingestion.docx_loader import Chunk


class VectorStore:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = QdrantClient(url=settings.qdrant_url, api_key=settings.qdrant_api_key or None)

    def ensure_collection(self) -> None:
        collections = self.client.get_collections().collections
        names = {collection.name for collection in collections}
        if self.settings.qdrant_collection in names:
            return
        self.client.create_collection(
            collection_name=self.settings.qdrant_collection,
            vectors_config=models.VectorParams(
                size=self.settings.vector_size,
                distance=models.Distance.COSINE,
            ),
        )

    def upsert(self, chunks: list[Chunk], vectors: list[list[float]]) -> None:
        self.ensure_collection()
        points = [
            models.PointStruct(
                id=index + 1,
                vector=vector,
                payload={
                    "chunk_id": chunk.id,
                    "title": chunk.title,
                    "text": chunk.text,
                    **chunk.metadata,
                },
            )
            for index, (chunk, vector) in enumerate(zip(chunks, vectors))
        ]
        self.client.upsert(collection_name=self.settings.qdrant_collection, points=points)

    def search(self, query_vector: list[float], limit: int = 5) -> list[dict]:
        hits = self.client.search(
            collection_name=self.settings.qdrant_collection,
            query_vector=query_vector,
            limit=limit,
            with_payload=True,
        )
        return [
            {
                "title": hit.payload.get("title", "Untitled"),
                "section": hit.payload.get("section"),
                "text": hit.payload.get("text", ""),
                "score": float(hit.score),
            }
            for hit in hits
        ]

