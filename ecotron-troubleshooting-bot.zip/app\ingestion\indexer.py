from pathlib import Path
import json

from app.config import Settings
from app.ingestion.docx_loader import Chunk, load_docx_chunks
from app.rag.embeddings import EmbeddingClient
from app.rag.vector_store import VectorStore


def index_docx(path: Path, settings: Settings) -> tuple[int, str]:
    chunks = load_docx_chunks(path)
    settings.local_index_path.parent.mkdir(parents=True, exist_ok=True)
    settings.local_index_path.write_text(
        json.dumps([_chunk_to_dict(chunk) for chunk in chunks], indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    if settings.has_gemini and settings.has_qdrant:
        embedder = EmbeddingClient(settings)
        vectors = embedder.embed_documents([chunk.text for chunk in chunks])
        store = VectorStore(settings)
        store.upsert(chunks, vectors)
        return len(chunks), "qdrant"

    return len(chunks), "local_json"


def _chunk_to_dict(chunk: Chunk) -> dict:
    return {
        "id": chunk.id,
        "title": chunk.title,
        "text": chunk.text,
        "metadata": chunk.metadata,
    }

