from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1)
    language: str = Field("English", pattern="^(English|Hindi|Marathi)$")
    technician_id: str | None = None


class Source(BaseModel):
    title: str
    section: str | None = None
    score: float | None = None


class ChatResponse(BaseModel):
    answer: str
    sources: list[Source]
    mode: str


class IndexResponse(BaseModel):
    indexed_chunks: int
    vector_store: str
    source_path: str

