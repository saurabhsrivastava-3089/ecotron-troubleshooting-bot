from google import genai

from app.config import Settings
from app.rag.prompts import build_prompt


class AnswerGenerator:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = genai.Client(api_key=settings.gemini_api_key) if settings.has_gemini else None

    def generate(self, message: str, language: str, contexts: list[dict]) -> tuple[str, str]:
        if self.client and contexts:
            prompt = build_prompt(message, language, contexts)
            result = self.client.models.generate_content(
                model=self.settings.gemini_model,
                contents=prompt,
            )
            return result.text or "No answer generated.", "gemini"

        return self._fallback_answer(message, language, contexts), "local_fallback"

    def _fallback_answer(self, message: str, language: str, contexts: list[dict]) -> str:
        if not contexts:
            return (
                "I could not find relevant KB content yet. Please index the DOCX first, "
                "then ask with the fault code, HP, motor type, pump type, and voltage reading."
            )
        top = contexts[0]
        return (
            "Likely issue:\n"
            f"Relevant KB section found: {top['title']}.\n\n"
            "Checks:\n"
            f"{top['text'][:1200]}\n\n"
            "Action:\n"
            "Follow the listed KB steps in order. For electrical checks, isolate power before touching terminals.\n\n"
            "Escalate if:\n"
            "The KB says to contact Tech Support, multiple fault codes appear, or the issue remains unresolved."
        )

