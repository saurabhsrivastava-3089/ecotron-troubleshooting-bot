# Ecotron Field Troubleshooting Bot

Python FastAPI web app for a multilingual RAG troubleshooting chatbot for Ecotron solar pump field technicians.

## Stack

- FastAPI backend
- Simple web chat UI
- Gemini for LLM and embeddings
- Qdrant for vector storage
- DOCX ingestion for the field knowledge base
- Local fallback retrieval when Gemini/Qdrant keys are not configured

## Setup

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` and add:

- `GEMINI_API_KEY`
- `QDRANT_URL`
- `QDRANT_API_KEY`

For quick local testing, the app can run without keys and will use keyword retrieval.

## Run

```powershell
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Open:

```text
http://127.0.0.1:8000
```

## First Index

Use the UI button or call:

```powershell
Invoke-RestMethod -Method Post http://127.0.0.1:8000/api/index
```

The default DOCX path is configured in `.env`.

## Current Product Behavior

- Supports English, Hindi, and Marathi response selection.
- Retrieves KB content by fault code, keywords, and metadata-like text.
- Uses strict field-technician prompting.
- Includes a correction chunk stating that 5HP POLY panel systems must use series/string connection.

