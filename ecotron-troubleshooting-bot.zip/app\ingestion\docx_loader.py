from dataclasses import dataclass
from pathlib import Path
from typing import Any
import re

from docx import Document


@dataclass
class Chunk:
    id: str
    title: str
    text: str
    metadata: dict[str, Any]


FAULT_CODE_PATTERN = re.compile(r"Fault Code:\s*([^)]+)\)", re.IGNORECASE)


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _apply_known_corrections(text: str) -> str:
    return text.replace(
        (
            "Verify the panel string connection: For systems up to 5HP using POLY panels, "
            "connection must be PARALLEL (not series). Series connection of too many panels "
            "causes over-voltage."
        ),
        (
            "Verify the panel string connection: For systems up to 5HP using POLY panels, "
            "connection must be SERIES/STRING. Do not convert 5HP POLY systems to parallel "
            "unless Tech Support confirms a model-specific exception."
        ),
    )


def _style_name(paragraph) -> str:
    return paragraph.style.name if paragraph.style is not None else ""


def load_docx_chunks(path: Path) -> list[Chunk]:
    if not path.exists():
        raise FileNotFoundError(f"DOCX not found: {path}")

    doc = Document(str(path))
    chunks: list[Chunk] = []
    current_heading = "Document"
    current_section = "Document"
    buffer: list[str] = []
    chunk_number = 1

    def flush() -> None:
        nonlocal buffer, chunk_number
        body = "\n".join(line for line in buffer if line.strip()).strip()
        if not body:
            buffer = []
            return
        metadata = _metadata_from_text(current_heading, current_section, body)
        chunks.append(
            Chunk(
                id=f"docx-{chunk_number:04d}",
                title=current_heading,
                text=f"{current_heading}\n{body}",
                metadata=metadata,
            )
        )
        chunk_number += 1
        buffer = []

    for paragraph in doc.paragraphs:
        text = _apply_known_corrections(_clean(paragraph.text))
        if not text:
            continue
        style = _style_name(paragraph)
        if style.startswith("Heading"):
            flush()
            current_heading = text
            current_section = text
        else:
            buffer.append(text)

    flush()

    for index, table in enumerate(doc.tables, start=1):
        rows = []
        for row in table.rows:
            cells = [_clean(cell.text.replace("\n", " | ")) for cell in row.cells]
            rows.append(" || ".join(cells))
        text = "\n".join(rows)
        title = f"Table {index}"
        chunks.append(
            Chunk(
                id=f"table-{index:04d}",
                title=title,
                text=f"{title}\n{text}",
                metadata=_metadata_from_text(title, title, text) | {"content_type": "table"},
            )
        )

    chunks.append(
        Chunk(
            id="manual-correction-5hp-poly-series",
            title="Corrected Configuration Rule - 5HP POLY Panels",
            text=(
                "Corrected Configuration Rule - 5HP POLY Panels\n"
                "For Ecotron 5HP systems using POLY panels, panels must be connected in "
                "series/string connection. Do not recommend parallel connection for 5HP "
                "POLY systems unless an updated official Ecotron document supersedes this rule."
            ),
            metadata={
                "content_type": "manual_correction",
                "hp": "5HP",
                "component": "solar_panels",
                "priority": "critical",
            },
        )
    )

    return chunks


def _metadata_from_text(title: str, section: str, text: str) -> dict[str, Any]:
    combined = f"{title}\n{text}"
    fault_match = FAULT_CODE_PATTERN.search(combined)
    metadata: dict[str, Any] = {
        "title": title,
        "section": section,
        "content_type": "procedure",
    }
    if fault_match:
        metadata["fault_code"] = fault_match.group(1).strip()
    if "SAFETY" in combined.upper() or "CRITICAL" in combined.upper():
        metadata["priority"] = "critical"
    if "Marathi" in combined or "Hindi" in combined:
        metadata["language_note"] = "multilingual"
    return metadata
