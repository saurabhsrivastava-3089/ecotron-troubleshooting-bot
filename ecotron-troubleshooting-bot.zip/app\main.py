from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.config import get_settings
from app.ingestion.indexer import index_docx
from app.rag.generator import AnswerGenerator
from app.rag.retriever import Retriever
from app.schemas import ChatRequest, ChatResponse, IndexResponse, Source


settings = get_settings()
app = FastAPI(title=settings.app_name)
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def home():
    return FileResponse("static/index.html")


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "gemini_configured": settings.has_gemini,
        "qdrant_configured": settings.has_qdrant,
        "local_index_exists": settings.local_index_path.exists(),
    }


@app.post("/api/index", response_model=IndexResponse)
def index_seed_document():
    try:
        count, store = index_docx(settings.default_docx_path, settings)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return IndexResponse(
        indexed_chunks=count,
        vector_store=store,
        source_path=str(settings.default_docx_path),
    )


@app.post("/api/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    retriever = Retriever(settings)
    contexts, retrieval_mode = retriever.retrieve(request.message)
    generator = AnswerGenerator(settings)
    answer, generation_mode = generator.generate(request.message, request.language, contexts)
    return ChatResponse(
        answer=answer,
        sources=[
            Source(
                title=item["title"],
                section=item.get("section"),
                score=item.get("score"),
            )
            for item in contexts
        ],
        mode=f"{retrieval_mode}+{generation_mode}",
    )

