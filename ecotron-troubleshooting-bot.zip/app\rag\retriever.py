import json
import re

from app.config import Settings
from app.rag.embeddings import EmbeddingClient
from app.rag.vector_store import VectorStore


class Retriever:
    def __init__(self, settings: Settings):
        self.settings = settings

    def retrieve(self, query: str, limit: int = 5) -> tuple[list[dict], str]:
        if self.settings.has_gemini and self.settings.has_qdrant:
            embedder = EmbeddingClient(self.settings)
            store = VectorStore(self.settings)
            return store.search(embedder.embed_query(query), limit=limit), "qdrant"

        return self._local_search(query, limit), "local_json"

    def _local_search(self, query: str, limit: int) -> list[dict]:
        if not self.settings.local_index_path.exists():
            return []
        chunks = json.loads(self.settings.local_index_path.read_text(encoding="utf-8"))
        query_terms = set(_tokens(query))
        scored = []
        for chunk in chunks:
            text = chunk["text"]
            terms = set(_tokens(text))
            score = len(query_terms & terms)
            fault_code = _fault_code(query)
            if fault_code and chunk.get("metadata", {}).get("fault_code") == fault_code:
                score += 20
            if "5hp" in query.lower() and "5HP" in text:
                score += 5
            if score:
                scored.append(
                    {
                        "title": chunk["title"],
                        "section": chunk.get("metadata", {}).get("section"),
                        "text": text,
                        "score": float(score),
                    }
                )
        scored.sort(key=lambda item: item["score"], reverse=True)
        return scored[:limit]


def _tokens(text: str) -> list[str]:
    return re.findall(r"[a-zA-Z0-9]+", text.lower())


def _fault_code(text: str) -> str | None:
    match = re.search(r"\b(?:fault\s*code\s*)?(\d{1,5})\b", text, re.IGNORECASE)
    return match.group(1) if match else None

